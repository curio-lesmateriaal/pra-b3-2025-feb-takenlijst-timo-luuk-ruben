<footer>
    <p>&copy; <?php echo date("Y"); ?> Developerland</p>
    <p>Neem contact op via <a href="mailto:info@developerland.nl">info@developerland.nl</a></p>
    <p>Volg ons op <a href="#">Twitter</a> en <a href="#">LinkedIn</a></p>
</footer>