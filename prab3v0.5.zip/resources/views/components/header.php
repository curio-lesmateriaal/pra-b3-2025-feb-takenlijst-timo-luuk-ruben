<header>
    <?php
    require_once __DIR__.'/../../../backend/config.php';
    ?>
    <div class="header">
        <a href="<?php echo $base_url; ?>/index.php">Home</a>
        <a href="<?php echo $base_url; ?>/tasks/planbord.php">Planbord</a>
        <a href="<?php echo $base_url; ?>/contact.php">Contact</a>
    </div>
</header>