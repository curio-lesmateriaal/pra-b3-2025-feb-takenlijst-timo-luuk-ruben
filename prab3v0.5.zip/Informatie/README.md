## Template B3 / Takenlijst
- Importeer de SQL-file vanuit de map `doc` in je phpMyAdmin.
- Kopieer de `config.example.php` naar `config.php`.